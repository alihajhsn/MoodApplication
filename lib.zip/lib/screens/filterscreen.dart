import 'package:flutter/material.dart';

class FilterScreen extends StatefulWidget {
  const FilterScreen({
    Key? key,
    required this.currentFilters,
  }) : super(key: key);

  final Map<String, bool> currentFilters; // ✅ Accepts filters for mood types

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  late bool _happyFilter;
  late bool _confidentFilter;
  late bool _tiredFilter;
  late bool _lovedFilter;
  late bool _sadFilter;
  late bool _neutralFilter;
  late bool _relaxedFilter;

  @override
  void initState() {
    super.initState();

    // ✅ Load initial filter states from `currentFilters`
    _happyFilter = widget.currentFilters["Happy"] ?? true;
    _confidentFilter = widget.currentFilters["Confident"] ?? true;
    _tiredFilter = widget.currentFilters["Tired"] ?? true;
    _lovedFilter = widget.currentFilters["Loved"] ?? true;
    _sadFilter = widget.currentFilters["Sad"] ?? true;
    _neutralFilter = widget.currentFilters["Neutral"] ?? true;
    _relaxedFilter = widget.currentFilters["Relaxed"] ?? true;
  }

  void _applyFilters() {
    final selectedFilters = {
      "Happy": _happyFilter,
      "Confident": _confidentFilter,
      "Tired": _tiredFilter,
      "Loved": _lovedFilter,
      "Sad": _sadFilter,
      "Neutral": _neutralFilter,
      "Relaxed": _relaxedFilter,
    };

    print("Filters applied: $selectedFilters"); // ✅ Debugging

    Navigator.pop(context, selectedFilters); // ✅ Pass selected filters to MoodHistoryScreen
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Filter Mood History"),
        leading: BackButton(
          onPressed: _applyFilters, // ✅ Ensure filters are passed when returning
        ),
      ),
      body: Column(
        children: [
          SwitchListTile(
            value: _happyFilter,
            onChanged: (isChecked) {
              setState(() {
                _happyFilter = isChecked;
              });
            },
            title: const Text("Happy"),
            subtitle: const Text("Only show happy moods."),
          ),
          SwitchListTile(
            value: _confidentFilter,
            onChanged: (isChecked) {
              setState(() {
                _confidentFilter = isChecked;
              });
            },
            title: const Text("Confident"),
            subtitle: const Text("Only show confident moods."),
          ),
          SwitchListTile(
            value: _tiredFilter,
            onChanged: (isChecked) {
              setState(() {
                _tiredFilter = isChecked;
              });
            },
            title: const Text("Tired"),
            subtitle: const Text("Only show tired moods."),
          ),
          SwitchListTile(
            value: _lovedFilter,
            onChanged: (isChecked) {
              setState(() {
                _lovedFilter = isChecked;
              });
            },
            title: const Text("Loved"),
            subtitle: const Text("Only show loved moods."),
          ),
          SwitchListTile(
            value: _sadFilter,
            onChanged: (isChecked) {
              setState(() {
                _sadFilter = isChecked;
              });
            },
            title: const Text("Sad"),
            subtitle: const Text("Only show sad moods."),
          ),
          SwitchListTile(
            value: _neutralFilter,
            onChanged: (isChecked) {
              setState(() {
                _neutralFilter = isChecked;
              });
            },
            title: const Text("Neutral"),
            subtitle: const Text("Only show neutral moods."),
          ),
          SwitchListTile(
            value: _relaxedFilter,
            onChanged: (isChecked) {
              setState(() {
                _relaxedFilter = isChecked;
              });
            },
            title: const Text("Relaxed"),
            subtitle: const Text("Only show relaxed moods."),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _applyFilters,
        icon: const Icon(Icons.done),
        label: const Text("Apply Filters"),
      ),
    );
  }
}
